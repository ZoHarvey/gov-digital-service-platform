# Government Digital Service Platform

Repository for showcasing Enterprise Architecture in a fictional govtech scenario.